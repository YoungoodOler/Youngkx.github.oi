import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const label = process.argv[2];
if (!label || !/^[a-z0-9-]+$/.test(label)) throw new Error('Supply a benchmark label');
const root = path.resolve('out');
const output = path.resolve('docs/benchmarks/2026-11-04', label);
mkdirSync(output, { recursive: true });
const server = createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://localhost');
    const filename = path.resolve(root, `.${decodeURIComponent(url.pathname)}`);
    if (filename !== root && !filename.startsWith(`${root}${path.sep}`)) {
      response.writeHead(403).end();
      return;
    }
    const file = (await stat(filename)).isDirectory()
      ? path.join(filename, 'index.html')
      : filename;
    const types = {
      '.html': 'text/html',
      '.css': 'text/css',
      '.js': 'application/javascript',
      '.woff2': 'font/woff2',
      '.png': 'image/png',
      '.svg': 'image/svg+xml',
    };
    response.writeHead(200, {
      'Content-Type': types[path.extname(file)] ?? 'application/octet-stream',
      'Cache-Control': 'no-store',
    });
    response.end(await readFile(file));
  } catch {
    response.writeHead(404).end();
  }
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
let browser;
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true });
  const results = [];
  for (const [name, viewport] of [
    ['desktop', { width: 1440, height: 900 }],
    ['mobile', { width: 390, height: 844 }],
  ]) {
    for (let sample = 0; sample < 5; sample++) {
      const context = await browser.newContext({
        viewport,
        reducedMotion: 'reduce',
        locale: 'zh-CN',
        timezoneId: 'Asia/Shanghai',
        colorScheme: 'dark',
        deviceScaleFactor: 1,
      });
      const page = await context.newPage();
      const errors = [];
      page.on('pageerror', (error) => errors.push(error.message));
      await page.addInitScript(() => {
        localStorage.setItem('youngkx-theme', 'dark');
        window.__benchmarkLcp = null;
        new PerformanceObserver((list) => {
          window.__benchmarkLcp = list.getEntries().at(-1)?.startTime ?? null;
        }).observe({ type: 'largest-contentful-paint', buffered: true });
      });
      await page.goto(`http://127.0.0.1:${server.address().port}/articles/`, { waitUntil: 'load' });
      await page.locator('.scene canvas').waitFor({ state: 'visible' });
      await page.waitForTimeout(2000);
      const session = await context.newCDPSession(page);
      await session.send('Performance.enable');
      const { metrics } = await session.send('Performance.getMetrics');
      const values = Object.fromEntries(
        metrics.map(({ name: metricName, value }) => [metricName, value]),
      );
      const navigation = await page.evaluate(() => {
        const nav = performance.getEntriesByType('navigation')[0];
        return {
          domContentLoadedMs: nav.domContentLoadedEventEnd,
          loadMs: nav.loadEventEnd,
          fcpMs: performance.getEntriesByName('first-contentful-paint')[0]?.startTime ?? null,
          lcpMs: window.__benchmarkLcp,
        };
      });
      assert.deepEqual(errors, []);
      results.push({
        name,
        sample: sample + 1,
        ...navigation,
        jsHeapUsedBytes: values.JSHeapUsedSize,
        scriptDurationSeconds: values.ScriptDuration,
        errors,
      });
      if (sample === 0) {
        await page.screenshot({
          path: path.join(output, `${name}.png`),
          fullPage: true,
          animations: 'disabled',
          mask: [page.locator('.global-particle-scene')],
          maskColor: '#0a0d13',
        });
      }
      await context.close();
    }
  }
  writeFileSync(
    path.join(output, 'browser.json'),
    `${JSON.stringify({ browser: browser.version(), conditions: { server: 'local uncompressed static HTTP, no-store', route: '/articles/', coldContexts: true, samplesPerViewport: 5, settleMs: 2000, reducedMotion: 'reduce', deviceScaleFactor: 1, screenshots: 'full page, animated canvas masked' }, results }, null, 2)}\n`,
  );
  console.log(JSON.stringify(results, null, 2));
} finally {
  await browser?.close();
  await new Promise((resolve) => server.close(resolve));
}
