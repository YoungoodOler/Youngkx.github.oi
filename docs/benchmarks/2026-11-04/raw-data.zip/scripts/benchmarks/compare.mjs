import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { build } from 'esbuild';
import sharp from 'sharp';

const directory = path.resolve('docs/benchmarks/2026-11-04');
const readJson = async (filename) =>
  JSON.parse(await readFile(path.join(directory, filename), 'utf8'));
const before = await readJson('before/all.json');
const after = await readJson('after/all.json');
assert.equal(before.environment.node, after.environment.node);
assert.equal(before.environment.lockSha256, after.environment.lockSha256);
const median = (values) => {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
};
const metrics = [];
function metric(name, unit, previous, next) {
  const a = median(previous);
  const b = median(next);
  metrics.push({
    name,
    unit,
    beforeSamples: previous,
    afterSamples: next,
    before: a,
    after: b,
    reductionPercent: a ? ((a - b) / a) * 100 : null,
  });
}
for (const [prefix, name] of [
  ['build-', 'clean-build'],
  ['budget-', 'performance-budget'],
]) {
  const a = before.measurements.filter((entry) => entry.name.startsWith(prefix));
  const b = after.measurements.filter((entry) => entry.name.startsWith(prefix));
  assert.equal(a.length, 3);
  assert.equal(b.length, 3);
  for (const entry of [...a, ...b]) assert.equal(entry.exitCode, 0);
  metric(
    `${name}-time`,
    'ms',
    a.map((entry) => entry.durationMs),
    b.map((entry) => entry.durationMs),
  );
  metric(
    `${name}-max-individual-node-rss`,
    'KiB',
    a.map((entry) => entry.maxProcessRssKiB),
    b.map((entry) => entry.maxProcessRssKiB),
  );
}
const aRuntime = await readJson('before/runtime.log');
const bRuntime = await readJson('after/runtime.log');
for (let index = 0; index < aRuntime.results.length; index++) {
  const a = aRuntime.results[index];
  const b = bRuntime.results[index];
  assert.equal(a.name, b.name);
  assert.equal(a.latencyMs, b.latencyMs);
  metric(
    `synthetic-${a.name}`,
    'ms',
    a.samples.map((sample) => sample.durationMs),
    b.samples.map((sample) => sample.durationMs),
  );
  metric(
    `synthetic-${a.name}-binding-operations`,
    'count',
    a.samples.map((sample) => sample.operations.length),
    b.samples.map((sample) => sample.operations.length),
  );
}
const aBrowser = await readJson('before/browser.json');
const bBrowser = await readJson('after/browser.json');
assert.equal(aBrowser.browser, bBrowser.browser);
assert.deepEqual(aBrowser.conditions, bBrowser.conditions);
for (const viewport of ['desktop', 'mobile']) {
  const a = aBrowser.results.filter((sample) => sample.name === viewport);
  const b = bBrowser.results.filter((sample) => sample.name === viewport);
  for (const field of ['domContentLoadedMs', 'loadMs', 'fcpMs', 'lcpMs', 'jsHeapUsedBytes']) {
    metric(
      `browser-${viewport}-${field}`,
      field.endsWith('Bytes') ? 'bytes' : 'ms',
      a.map((sample) => sample[field]),
      b.map((sample) => sample[field]),
    );
  }
}
const preservation = {};
const aAssets = await readJson('before/assets.json');
const bAssets = await readJson('after/assets.json');
const visualAssets = (assets) =>
  assets
    .filter((asset) => /\.(?:css|woff2?|ttf|otf)$/.test(asset.path))
    .map(({ bytes, sha256 }) => ({ bytes, sha256 }))
    .sort((a, b) => a.sha256.localeCompare(b.sha256));
assert.deepEqual(visualAssets(aAssets), visualAssets(bAssets));
preservation.stylesAndFontsUnchanged = true;
for (const viewport of ['desktop', 'mobile']) {
  const a = await sharp(path.join(directory, 'before', `${viewport}.png`))
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  const b = await sharp(path.join(directory, 'after', `${viewport}.png`))
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  assert.deepEqual(a.info, b.info);
  let differentPixels = 0;
  let differentPixelsAboveFooter = 0;
  const footerStart = viewport === 'desktop' ? 2200 : 2160;
  for (let index = 0; index < a.data.length; index += 4) {
    if (!a.data.subarray(index, index + 4).equals(b.data.subarray(index, index + 4))) {
      differentPixels++;
      if (index / 4 / a.info.width < footerStart) differentPixelsAboveFooter++;
    }
  }
  preservation[`${viewport}Screenshot`] = {
    ...a.info,
    differentPixels,
    differentPixelsAboveFooter,
    footerStart,
    comparedPixels: a.info.width * a.info.height,
  };
}
const temporary = await mkdtemp(path.join(os.tmpdir(), 'youngkx-content-'));
try {
  const records = [];
  for (const [label, source] of [
    [
      'before',
      execFileSync('git', ['show', `${before.commit}:lib/markdown-articles.ts`], {
        encoding: 'utf8',
      }),
    ],
    ['after', await readFile('lib/markdown-articles.ts', 'utf8')],
  ]) {
    const outfile = path.join(temporary, `${label}.cjs`);
    await build({
      stdin: { contents: source, resolveDir: path.resolve('lib'), loader: 'ts' },
      bundle: true,
      platform: 'node',
      format: 'cjs',
      outfile,
      logLevel: 'silent',
    });
    const articleModule = await import(pathToFileURL(outfile).href);
    records.push(articleModule.loadMarkdownArticles());
  }
  assert.deepEqual(records[0], records[1]);
  preservation.markdown = records[1].map((article) => ({
    path: article.path,
    title: article.title,
    contentSha256: createHash('sha256').update(article.content).digest('hex'),
  }));
  const original = execFileSync('git', ['show', `${before.commit}:content/articles.json`]);
  assert.deepEqual(
    JSON.parse(await readFile('content/articles.json', 'utf8')),
    JSON.parse(original.toString('utf8')),
  );
  preservation.legacyContentUnchanged = true;
} finally {
  await rm(temporary, { recursive: true, force: true });
}
await writeFile(
  path.join(directory, 'comparison.json'),
  `${JSON.stringify({ beforeCommit: before.commit, sameDependencyLock: before.environment.lockSha256, metrics, preservation }, null, 2)}\n`,
);
console.table(
  metrics.map(({ name, before: a, after: b, reductionPercent }) => ({
    name,
    before: a.toFixed(2),
    after: b.toFixed(2),
    reductionPercent: reductionPercent?.toFixed(2),
  })),
);
console.log(JSON.stringify(preservation, null, 2));
