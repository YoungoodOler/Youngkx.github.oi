/* eslint-disable @typescript-eslint/no-require-imports -- Node --require preload must be CommonJS. */
// Loaded into each measured Node process, including its Node subprocesses.
const { writeFileSync } = require('node:fs');
const path = require('node:path');

process.on('exit', () => {
  if (!process.env.YOUNGKX_BENCH_RESOURCES) return;
  writeFileSync(
    path.join(process.env.YOUNGKX_BENCH_RESOURCES, `${process.pid}.json`),
    JSON.stringify({
      pid: process.pid,
      argv: process.argv.slice(1),
      resourceUsage: process.resourceUsage(),
      memoryAtExit: process.memoryUsage(),
    }),
  );
});
