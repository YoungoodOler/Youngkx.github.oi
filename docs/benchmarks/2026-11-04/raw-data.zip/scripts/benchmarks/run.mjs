import { spawn, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(fileURLToPath(new URL('../..', import.meta.url)));
process.chdir(root);
const label = process.argv[2];
if (!label || !/^[a-z0-9-]+$/.test(label))
  throw new Error('Usage: node scripts/benchmarks/run.mjs <label> [checks|measure|all]');
const phase = process.argv[3] ?? 'all';
if (!['checks', 'measure', 'all'].includes(phase)) throw new Error('Unknown phase');
const output = path.join(root, 'docs', 'benchmarks', '2026-11-04', label);
mkdirSync(output, { recursive: true });
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const report = {
  label,
  phase,
  startedAt: new Date().toISOString(),
  commit: git('rev-parse', 'HEAD'),
  status: git('status', '--short'),
  diffSha256: createHash('sha256')
    .update(git('diff', '--', '.', ':!docs/benchmarks'))
    .digest('hex'),
  environment: {
    node: process.version,
    execPath: process.execPath,
    platform: process.platform,
    arch: process.arch,
    os: os.release(),
    cpu: os.cpus()[0]?.model,
    logicalCpus: os.cpus().length,
    totalMemoryBytes: os.totalmem(),
    nodeOptions: process.env.NODE_OPTIONS ?? '',
    lockSha256: createHash('sha256').update(readFileSync('package-lock.json')).digest('hex'),
  },
  measurements: [],
};
const reportFile = path.join(output, `${phase}.json`);
const save = () => writeFileSync(reportFile, `${JSON.stringify(report, null, 2)}\n`);
save();
async function run(name, args) {
  const resources = path.join(output, `${name}-resources`);
  mkdirSync(resources, { recursive: true });
  const started = performance.now();
  let log = '';
  const preload = path.join(root, 'scripts', 'benchmarks', 'resources.cjs');
  console.log(`Starting ${name}`);
  const exitCode = await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, args, {
      cwd: root,
      env: {
        ...process.env,
        NEXT_TELEMETRY_DISABLED: '1',
        WRANGLER_SEND_METRICS: 'false',
        YOUNGKX_BENCH_RESOURCES: resources,
        NODE_OPTIONS: `${process.env.NODE_OPTIONS ?? ''} --require ${JSON.stringify(preload)}`,
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    child.stdout.on('data', (chunk) => {
      log += chunk;
    });
    child.stderr.on('data', (chunk) => {
      log += chunk;
    });
    child.on('error', reject);
    child.on('close', resolve);
  });
  const durationMs = performance.now() - started;
  writeFileSync(path.join(output, `${name}.log`), log);
  const usage = readdirSync(resources)
    .filter((file) => file.endsWith('.json'))
    .map((file) => JSON.parse(readFileSync(path.join(resources, file), 'utf8')));
  // Maximum individual Node process HWM; never presented as total process-tree memory.
  const maxProcessRssKiB = usage.length
    ? Math.max(...usage.map((item) => item.resourceUsage.maxRSS))
    : null;
  report.measurements.push({
    name,
    args,
    exitCode,
    durationMs,
    maxProcessRssKiB,
    nodeProcessCount: usage.length,
  });
  save();
  console.log(
    `${name}: exit ${exitCode}, ${(durationMs / 1000).toFixed(3)} s, max individual Node RSS ${maxProcessRssKiB} KiB`,
  );
  if (exitCode !== 0) {
    console.error(log.slice(-3500));
    process.exitCode = 1;
  }
}
if (phase !== 'measure') {
  await run('types-app', ['node_modules/typescript/bin/tsc', '--noEmit']);
  await run('types-worker', [
    'node_modules/typescript/bin/tsc',
    '-p',
    'cloudflare/tsconfig.json',
    '--noEmit',
  ]);
  await run('lint', ['node_modules/eslint/bin/eslint.js', '.', '--max-warnings=0']);
  await run('tests', [
    'node_modules/vitest/vitest.mjs',
    'run',
    '--config',
    'config/vitest.config.mts',
  ]);
}
if (phase !== 'checks') {
  for (let index = 1; index <= 3; index++) {
    // Delete only these exact generated directories, after checking their resolved parents.
    for (const name of ['.next', 'out']) {
      const target = path.resolve(root, name);
      if (path.dirname(target) !== root) throw new Error('Unsafe build path');
      rmSync(target, { recursive: true, force: true });
    }
    await run(`build-${index}`, ['node_modules/next/dist/bin/next', 'build']);
    await run(`budget-${index}`, ['scripts/check-performance-budget.mjs']);
  }
  await run('runtime', ['scripts/benchmarks/runtime.mjs']);
  const files = [];
  function walk(directory) {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const filename = path.join(directory, entry.name);
      if (entry.isDirectory()) walk(filename);
      else {
        const data = readFileSync(filename);
        files.push({
          path: path.relative('out', filename).replaceAll('\\', '/'),
          bytes: data.length,
          sha256: createHash('sha256').update(data).digest('hex'),
        });
      }
    }
  }
  walk('out');
  writeFileSync(path.join(output, 'assets.json'), `${JSON.stringify(files, null, 2)}\n`);
}
