import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';

const directory = await mkdtemp(path.join(os.tmpdir(), 'youngkx-runtime-'));
try {
  const outfile = path.join(directory, 'worker.mjs');
  await build({ entryPoints: ['cloudflare/worker.ts'], outfile, bundle: true, format: 'esm' });
  const { default: worker } = await import(pathToFileURL(outfile).href);
  const id = '8000000000000-12345678-1234-1234-1234-123456789abc';
  const operations = [];
  // Each binding operation has the same synthetic latency, not a Cloudflare measurement.
  const latencyMs = 20;
  const metadata = { size: 1024, httpEtag: '"fixture"' };
  const env = {
    FILES: {
      async get(key, options) {
        operations.push(`get:${key}`);
        await delay(latencyMs);
        if (key === 'settings/repository.json') return null;
        if (key.startsWith('settings/')) return null;
        if (key.startsWith('files/')) {
          const length = options?.range?.length ?? metadata.size;
          return { ...metadata, body: new Response(new Uint8Array(length)).body };
        }
        return null;
      },
      async head(key) {
        operations.push(`head:${key}`);
        await delay(latencyMs);
        if (key.startsWith('file-records/')) {
          return {
            key,
            uploaded: new Date('2026-01-01T00:00:00Z'),
            customMetadata: { size: '1024', name: 'fixture.bin' },
          };
        }
        return metadata;
      },
      async list({ prefix }) {
        operations.push(`list:${prefix}`);
        await delay(latencyMs);
        return { objects: [], truncated: false };
      },
    },
  };
  const scenarios = [
    { name: 'file-list', pathname: '/api/files', init: {}, status: 200 },
    {
      name: 'range-head',
      pathname: `/api/files/${id}`,
      init: { method: 'HEAD', headers: { Range: 'bytes=0-9' } },
      status: 206,
    },
  ];
  const results = [];
  for (const scenario of scenarios) {
    const samples = [];
    for (let index = 0; index < 12; index++) {
      operations.length = 0;
      const started = performance.now();
      const response = await worker.fetch(
        new Request(`https://www.youngkx.cn${scenario.pathname}`, scenario.init),
        env,
      );
      await response.arrayBuffer();
      assert.equal(response.status, scenario.status);
      if (scenario.name === 'range-head')
        assert.equal(response.headers.get('content-length'), '10');
      if (index >= 2)
        samples.push({ durationMs: performance.now() - started, operations: [...operations] });
    }
    results.push({ name: scenario.name, latencyMs, warmups: 2, samples });
  }
  console.log(JSON.stringify({ kind: 'synthetic-binding-latency', results }, null, 2));
} finally {
  await rm(directory, { recursive: true, force: true });
}
